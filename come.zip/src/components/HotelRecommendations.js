import React from "react";
import {
  Box,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Chip,
  Grid,
  Button,
} from "@mui/material";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import LocalOfferIcon from "@mui/icons-material/LocalOffer";

const HotelRecommendations = ({ hotels = [], preferredHotels = [], userData }) => {
  const defaultImage =
    "https://via.placeholder.com/300x200?text=No+Image+Available";

  // Helper function to render a hotel card
  const renderHotelCard = (hotel, index) => {
    let discountedPrice = null;
    if (
      userData &&
      userData.travel_points &&
      hotel.offers &&
      hotel.offers.h_point_value != null
    ) {
      discountedPrice = Math.round(
        userData.travel_points * hotel.offers.h_point_value
      );
    }

    return (
      <Card
        key={index}
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          mb: 2,
          borderRadius: 2,
          border: "1px solid #e0e0e0",
          boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
          overflow: "hidden",
        }}
      >
        <CardMedia
          component="img"
          sx={{ width: { xs: "100%", md: 200 }, minHeight: 200 }}
          image={hotel.images?.[0]?.thumbnail || hotel.images?.[0]?.original_image || defaultImage}
          alt={hotel.name}
        />

        <CardContent sx={{ flex: "1 0 auto", p: 2 }}>
          <Typography
            variant="h6"
            fontWeight="bold"
            sx={{ color: "#006E74" }}
            gutterBottom
          >
            {hotel.name}
          </Typography>
          <Typography
            variant="body2"
            color="textSecondary"
            sx={{ mb: 1 }}
          >
            {hotel.description}
          </Typography>

          <Box sx={{ display: "flex", alignItems: "center", mb: 1 }}>
            <LocationOnIcon
              fontSize="small"
              color="action"
              sx={{ transition: "color 0.3s" }}
            />
            <Typography
              variant="body2"
              color="textSecondary"
              sx={{ ml: 0.5 }}
            >
              <a
                href={`https://www.google.com/maps?q=${hotel.gps_coordinates.latitude},${hotel.gps_coordinates.longitude}`}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  textDecoration: "none",
                  color: "inherit",
                  transition: "color 0.3s",
                }}
                onMouseEnter={(e) => (e.target.style.color = "#006E74")}
                onMouseLeave={(e) => (e.target.style.color = "inherit")}
              >
                View on Google Maps
              </a>
            </Typography>
          </Box>

          {hotel.offers?.h_offers?.length > 0 && (
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1, mb: 2 }}>
              {hotel.offers.h_offers.map((offer, index) => (
                <Chip
                  key={index}
                  icon={<LocalOfferIcon style={{ fontSize: 16 }} />}
                  label={
                    <Typography
                      variant="caption"
                      sx={{ fontSize: "0.6rem" }}
                    >
                      {`${offer.offer_name} (${offer.offer_percentage}% OFF)`}
                    </Typography>
                  }
                  color="secondary"
                  size="small"
                />
              ))}
            </Box>
          )}

          <Grid container spacing={1} sx={{ mb: 2, alignItems: "center" }}>
            <Grid item xs={6} sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Typography variant="body2">
                <strong>Nightly Price:</strong>{" "}
                {hotel.price?.nightly?.lowest || "N/A"}
              </Typography>
              {discountedPrice !== null && discountedPrice!==0 && (
                <Chip
                  label={`Travel Points Discount: ₹${discountedPrice}`}
                  sx={{
                    backgroundColor: "#E3F2FD",
                    color: "#1565C0",
                    fontWeight: "bold",
                    fontSize: "0.8rem",
                    height: "24px",
                  }}
                />
              )}
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2">
                <strong>Total Price:</strong>{" "}
                {hotel.price?.total?.lowest || "N/A"}
              </Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2">
                <strong>Check-in:</strong>{" "}
                {`${hotel.check_in?.date || ""}, ${hotel.check_in?.time || ""}`}
              </Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2">
                <strong>Check-out:</strong>{" "}
                {`${hotel.check_out?.date || ""}, ${hotel.check_out?.time || ""}`}
              </Typography>
            </Grid>
          </Grid>

          <Button
            variant="contained"
            sx={{ backgroundColor: "#006E74", color: "white" }}
            size="small"
            href={hotel.link || "#"}
            target="_blank"
            rel="noopener noreferrer"
            disabled={!hotel.link}
          >
            Visit Hotel
          </Button>
        </CardContent>
      </Card>
    );
  };

  // If hotels list is empty, display a message.
  if (hotels.length === 0) {
    return (
      <Box sx={{ p: 2 }}>
        <Typography variant="body1">
          No hotel recommendations available.
        </Typography>
      </Box>
    );
  }

  // If preferredHotels is provided, filter the hotels into two groups.
  let content = null;
  if (preferredHotels.length > 0) {
    // Convert preferred hotel names to lower case for a case-insensitive comparison
    const preferredHotelNames = preferredHotels.map((name) => name.toLowerCase().trim());
    const preferredHotelsFiltered = hotels.filter((hotel) =>
      preferredHotelNames.includes(hotel.name.toLowerCase())
    );
    const otherHotels = hotels.filter(
      (hotel) => !preferredHotelNames.includes(hotel.name.toLowerCase())
    );

    content = (
      <>
        {preferredHotelsFiltered.length > 0 && (
          <Box sx={{ mb: 4 }}>
            <Typography variant="h5" sx={{ mb: 2, color: '#006E74', fontWeight: 'bold' }}>
              Preferred Hotels
            </Typography>
            {preferredHotelsFiltered.map((hotel, index) =>
              renderHotelCard(hotel, index)
            )}
          </Box>
        )}

        {otherHotels.length > 0 && (
          <Box>
            <Typography variant="h5" sx={{ mb: 2, color: '#006E74', fontWeight: 'bold' }}>
              Other Hotels
            </Typography>
            {otherHotels.map((hotel, index) => renderHotelCard(hotel, index))}
          </Box>
        )}
      </>
    );
  } else {
    // If no preferredHotels are provided, simply list all hotels.
    content = hotels.map((hotel, index) => renderHotelCard(hotel, index));
  }

  return <Box sx={{ p: 2 }}>{content}</Box>;
};

export default HotelRecommendations;