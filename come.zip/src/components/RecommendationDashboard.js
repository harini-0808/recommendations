import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  TextField,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  Chip,
} from '@mui/material';
import { IconButton } from '@mui/material';
import { Close } from '@mui/icons-material';
import { toast, ToastContainer } from "react-toastify";
import { LinearProgress } from '@mui/joy';
import "react-toastify/dist/ReactToastify.css";
import FlightTakeoffIcon from '@mui/icons-material/FlightTakeoff';
import HotelIcon from '@mui/icons-material/Hotel';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import FlightRecommendations from './FlightRecommendations';
import HotelRecommendations from './HotelRecommendations';
import TravelPatternCards from './TravelPatternCards';
import LoyaltyIcon from '@mui/icons-material/Loyalty';
import RestaurantsRecommendations from './RestaurantsRecommendations';

const RecommendationDashboard = () => {
  const [travelDate, setTravelDate] = useState('');
  const [patterns, setPatterns] = useState([]);
  const [selectedFlights, setSelectedFlights] = useState([]);
  const [preferredAirlies, setPreferredAirlines] = useState([]);
  const [selectedHotels, setSelectedHotels] = useState([]);
  const [selectedRestaurants, setSelectedRestaurants] =useState([]);
  const [preferredRestaurants, setPreferredRestaurants] = useState([]);
  const [showRestaurantModal, setShowRestaurantModal] = useState(false);
  const [showFlightModal, setShowFlightModal] = useState(false);
  const [showHotelModal, setShowHotelModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [preferredHotels, setPreferredHotels] = useState(null);
  const [flightHistory, setFlightHistory] = useState([]);
  const [travelPattern, setTravelPattern] = useState(null);
  const [userData, setUserData] = useState(null);

  // const userData = JSON.parse(localStorage.getItem('userData'));

  useEffect(() => {
    const userData = localStorage.getItem('userData');
    if (userData) {
      const parsedUser = JSON.parse(userData);
      setUserData(parsedUser);
      if (parsedUser.role === 'customer') {
        if (parsedUser.flight_history && parsedUser.flight_history.length > 0) {
          setFlightHistory(parsedUser.flight_history);
        }
        if (parsedUser.travel_pattern) {
          setTravelPattern(parsedUser.travel_pattern);
        }
      }
    }
  }, []);

  const fetchRecommendations = async () => {
    if (!travelDate) {
      toast.error("Please select a travel date.", {
        position: "top-right",
      });
      return;
    }

    setPatterns([]);
    setLoading(true);
    setProgress(0);

    try {
      const response = await fetch('http://localhost:8001/recommendations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email_id: userData.email_id,
          travel_date: travelDate,
        }),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let partialChunk = '';
      let receivedCount = 0;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
  
        receivedCount++;
        setProgress(Math.min((receivedCount / 10) * 100, 95)); // Simulate progress
  
        const chunk = decoder.decode(value, { stream: true });
        partialChunk += chunk;
  
        const lines = partialChunk.split('\n');
        partialChunk = lines.pop() || '';
  
        lines.forEach(line => {
          if (line.trim()) {
            try {
              const parsedData = JSON.parse(line.trim());
              if (parsedData.error) throw new Error(parsedData.error);
              
              setPatterns(prev => {
                const exists = prev.some(p => p.cluster_id === parsedData.cluster_id);
                return exists ? prev : [...prev, parsedData];
              });
            } catch (error) {
              console.error('Error parsing:', error);
            }
          }
        });
      }

      if (partialChunk.trim()) {
        try {
          const parsedData = JSON.parse(partialChunk.trim());
          setPatterns(prevPatterns => {
            const isDuplicate = prevPatterns.some(p => 
              p.cluster_id === parsedData.cluster_id
            );
            return isDuplicate ? prevPatterns : [...prevPatterns, parsedData];
          });
        } catch (parseError) {
          console.error('Error parsing final chunk:', parseError);
        }
      }
      setProgress(100);
    } catch (error) {
      console.error('Error fetching recommendations:', error);
      toast.error(error.message || 'Failed to fetch recommendations. Please try again.', {
        position: "top-right",
      });
    } finally {
      setTimeout(() => setLoading(false), 500); // Smooth transition
    }
  };

  const handleFlightDetails = (flights, preferred_airlines) => {
    if (flights && flights.length > 0) {
      setSelectedFlights(flights);
      setPreferredAirlines(preferred_airlines);
      setShowFlightModal(true);
    } else {
      toast.error("No flight recommendations available.", {
        position: "top-right",
      });
    }
  };

  const handleHotelDetails = (hotels, preferred_hotel) => {
    if (hotels && hotels.length > 0) {
      setSelectedHotels(hotels);
      setPreferredHotels(preferred_hotel); 
      setShowHotelModal(true);
    } else {
      toast.error("No hotel recommendations available.", {
        position: "top-right",
      });
    }
  };

  const handleRestaurantsDetails = (restaurants, preferred_restaurant) => {
    if (restaurants && restaurants.length > 0) {
      setSelectedRestaurants(restaurants);
      setPreferredRestaurants(preferred_restaurant); 
      setShowRestaurantModal(true);
    } else {
      toast.error("No Restaurants recommendations available.", {
        position: "top-right",
      });
    }
  };

    return (
      <Container maxWidth="xl" sx={{ py: 4, position: 'relative' }}>
      <Box 
      sx={{ 
        position: 'absolute', 
        top: 20, 
        right: 16, 
        display: 'flex', 
        alignItems: 'center', 
        gap: 1,
        backgroundColor: '#f0f4f6',
        padding: '8px 16px',
        borderRadius: 2,
        boxShadow: 1,
        color: '#006E74'
      }}
      >
      <PersonOutlineIcon sx={{ fontSize: 24, mr: 1 }} />
      <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
        Hello, {userData?.customer_name || 'User'}
      </Typography>

      <Chip
        icon={<LoyaltyIcon />}
        label={`${userData?.travel_points || 0} Travel Points`}
        sx={{
          ml: 2,
          backgroundColor: '#006E74',
          color: 'white',
          fontWeight: 'bold',
          '& .MuiChip-icon': {
            color: '#FFD700',
          },
        }}
      />

      </Box>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, width: '100%' }}>
          <Typography 
            variant="h4" 
            sx={{ 
              color: '#006E74', 
              fontWeight: 'bold', 
              mb: 2,
              textAlign: 'left',
              borderBottom: '2px solid #006E74',
              paddingBottom: 1
            }}
          >
            Travel Recommendations
          </Typography>
        
        {travelPattern && (
        <Box sx={{ mt: 1 }}>
          <TravelPatternCards travelPattern={travelPattern} />
        </Box>
        )}
          
        <Box 
          sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: 2, 
            mb: 2,
            backgroundColor: '#f0f4f6',
            padding: 2,
            borderRadius: 2
          }}
        >
          <Typography sx={{ minWidth: 120 }}>Select Travel Date:</Typography>
          <TextField
            type="date"
            value={travelDate}
            onChange={(e) => setTravelDate(e.target.value)}
            variant="outlined"
            size="small"
            sx={{
              '& .MuiOutlinedInput-root': {
                '& fieldset': {
                  borderColor: '#006E74',
                },
                '&:hover fieldset': {
                  borderColor: '#004F52',
                },
                '&.Mui-focused fieldset': {
                  borderColor: '#006E74',
                },
              },
            }}
            InputLabelProps={{ shrink: true }}
            inputProps={{ 
              min: new Date().toISOString().split('T')[0],
              style: { 
                color: '#006E74' 
              }
            }}
          />
          <Button
            variant="contained"
            onClick={fetchRecommendations}
            disabled={loading}
            sx={{ 
              backgroundColor: '#006E74', 
              '&:hover': { backgroundColor: '#004F52' },
              '&.Mui-disabled': {
                backgroundColor: '#a0c4c8',
                color: 'white'
              },
              minWidth: 180
            }}
          >
            {loading ? 'Loading...' : 'Get Recommendations'}
          </Button>
        </Box>




{/* ---------------------------PAST TRAVEL DETAILS START------------------------- */} 
        <Typography 
          variant="h6" 
          sx={{ 
            color: '#006E74', 
            fontWeight: 'bold', 
            textAlign: 'center', 
            mb: 0.5, 
            p: 0.7, 
            // borderBottom: '3px solid #006E74',
            letterSpacing: 1.2,
            textTransform: 'uppercase'
          }}
        >
          Past Flights
        </Typography>

        {flightHistory.length > 0 && (
          <TableContainer 
            component={Paper} 
            sx={{ 
              mb: 4, 
              borderRadius: 2, 
              boxShadow: 3, 
              backgroundColor: '#f0f4f6', 
              maxHeight: 400, // Set the maximum height for the container
              overflowY: 'auto' // Enable vertical scrolling
            }}
          >
            <Table stickyHeader sx={{ minWidth: 650 }}>
              <TableHead>
                <TableRow>
                  {[
                    'Flight No', 'Departure', 'Arrival', 
                    'Date', 'Time', 'Travel Class', 'Airline'
                  ].map((header) => (
                    <TableCell 
                      key={header} 
                      sx={{ 
                        color: 'white', 
                        fontWeight: 'bold', 
                        textTransform: 'uppercase', 
                        // borderBottom: '2px solid rgba(255,255,255,0.2)',
                        backgroundColor: '#006E74'
                      }}
                    >
                      {header}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {flightHistory.map((flight, index) => (
                  <TableRow 
                    key={index}
                    hover
                    sx={{ 
                      '&:nth-of-type(even)': { 
                        backgroundColor: '#e6f2f4' 
                      },
                      '&:hover': { 
                        backgroundColor: '#d0e8eb !important' 
                      }
                    }}
                  >
                    {[
                      flight.flight_no,
                      flight.departure_id,
                      flight.arrival_id,
                      flight.outbound_date,
                      flight.outbound_time,
                      flight.travel_class,
                      flight.airline
                    ].map((cellData, cellIndex) => (
                      <TableCell 
                        key={cellIndex}
                        sx={{ 
                          color: '#333', 
                          fontWeight: 'medium', 
                          borderBottom: '1px solid rgba(0,0,0,0.1)' 
                        }}
                      >
                        {cellData}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}

{/* -------------------------------PAST TRAVEL DETAILS END------------------------ */}


        <Typography 
          variant="h6" 
          sx={{ 
            color: '#006E74', 
            fontWeight: 'bold', 
            textAlign: 'center', 
            mb: 0.5, 
            p: 0.7, 
            // borderBottom: '3px solid #006E74',
            letterSpacing: 1.2,
            textTransform: 'uppercase'
          }}
        >
          Travel Patterns
        </Typography>
        
        {loading && (
          <LinearProgress 
          color="neutral"
          sx={{
            "--LinearProgress-radius": "30px",
            "--LinearProgress-progressThickness": "5px"
          }}
          />
        )}

        {/* Patterns Table */}
        {patterns.length > 0 ? (
        <TableContainer 
        component={Paper} 
        sx={{ 
          borderRadius: 2, 
          boxShadow: 3,
          backgroundColor: '#f0f4f6' 
        }}
        >
          <Table sx={{ minWidth: 650 }}>
            <TableHead sx={{ backgroundColor: '#006E74' }}>
              <TableRow>
                {[
                  'Cluster ID', 'Frequency', 'Departure', 
                  'Arrival', 'Preferred Class', 'Preferred Airlines', 'Actions'
                ].map((header) => (
                  <TableCell 
                    key={header} 
                    sx={{ 
                      color: 'white', 
                      fontWeight: 'bold', 
                      textTransform: 'uppercase',
                      borderBottom: '2px solid rgba(255,255,255,0.2)'
                    }}
                  >
                    {header}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {patterns.map((pattern, index) => (
                <TableRow 
                  key={pattern.cluster_id || index}
                  hover
                  sx={{ 
                    '&:nth-of-type(even)': { 
                      backgroundColor: '#e6f2f4' 
                    },
                    '&:hover': { 
                      backgroundColor: '#d0e8eb !important' 
                    }
                  }}
                >
                  <TableCell sx={{ color: '#333', fontWeight: 'medium' }}>
                    {pattern.cluster_id || '0'}
                  </TableCell>
                  <TableCell sx={{ color: '#333', fontWeight: 'medium' }}>
                    {pattern.pattern?.frequency || 'N/A'}
                  </TableCell>
                  <TableCell sx={{ color: '#333', fontWeight: 'medium' }}>
                    {pattern.pattern?.details?.common_departure || 'N/A'}
                  </TableCell>
                  <TableCell sx={{ color: '#333', fontWeight: 'medium' }}>
                    {pattern.pattern?.details?.common_arrival || 'N/A'}
                  </TableCell>
                  <TableCell sx={{ color: '#333', fontWeight: 'medium' }}>
                    {pattern.pattern?.details?.preferred_class || 'N/A'}
                  </TableCell>
                  <TableCell sx={{ color: '#333', fontWeight: 'medium' }}>
                    {pattern.pattern?.details?.preferred_airlines?.join(', ') || 'N/A'}
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Button
                        variant="contained"
                        size="small"
                        onClick={() => handleFlightDetails(pattern.recommendations?.flights, pattern.pattern?.details?.preferred_airlines)}
                        sx={{
                          backgroundColor: '#006E74',
                          '&:hover': { backgroundColor: '#004F52' },
                          minWidth: 120,
                          padding: '6px 12px',
                          fontWeight: 'bold',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 1,
                        }}
                      >
                        <FlightTakeoffIcon sx={{ fontSize: 18 }} />
                        Flights
                      </Button>

                      <Button
                        variant="contained"
                        size="small"
                        onClick={() => handleHotelDetails(pattern.recommendations?.hotels, pattern.pattern?.details?.preferred_hotels)}
                        sx={{
                          backgroundColor: '#006E74',
                          '&:hover': { backgroundColor: '#004F52' },
                          minWidth: 120,
                          padding: '6px 12px',
                          fontWeight: 'bold',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 1,
                        }}
                      >
                        <HotelIcon sx={{ fontSize: 18 }} />
                        Hotels
                      </Button>

                      <Button
                        variant="contained"
                        size="small"
                        onClick={() => handleRestaurantsDetails(pattern.recommendations?.restaurants, pattern.pattern?.details?.preferred_restaurant)}
                        sx={{
                          backgroundColor: '#006E74',
                          '&:hover': { backgroundColor: '#004F52' },
                          minWidth: 120,
                          padding: '6px 12px',
                          fontWeight: 'bold',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 1,
                        }}
                      >
                        <HotelIcon sx={{ fontSize: 18 }} />
                        Restaurants
                      </Button>

                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        ) : (
          <Typography 
            variant="body1" 
            sx={{ 
              color: '#006E74', 
              textAlign: 'center', 
              p: 2, 
              backgroundColor: '#f0f4f6',
              borderRadius: 2
            }}
          >
            No recommendations found. Please select a date and fetch recommendations.
          </Typography>
        )}
        {/* Modals for Flight, Hotel and Restaurants Recommendations */}
        <Dialog
          open={showFlightModal}
          onClose={() => setShowFlightModal(false)}
          maxWidth="lg"
          fullWidth
          sx={{
            '& .MuiDialog-paper': {
              borderRadius: '16px',
              padding: '16px',
              boxShadow: '0 4px 16px rgba(0, 0, 0, 0.1)',
            },
          }}
        >
          <DialogTitle
            sx={{
              fontSize: '1.6rem',
              fontWeight: 'bold',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              borderBottom: '1px solid #e0e0e0',
              paddingBottom: '8px',
              color: '#006E74', // Use the theme's primary color
              backgroundColor: 'background.paper', // Matches the page's background theme
            }}
          >
              Flight Recommendations
            <IconButton
              onClick={() => setShowFlightModal(false)}
              sx={{
                color: '#333',
                '&:hover': {
                  color: '#006E74',
                },
              }}
            >
              <Close />
            </IconButton>
          </DialogTitle>
          <DialogContent
            sx={{
              paddingTop: '16px',
              paddingBottom: '16px',
              fontFamily: 'Roboto, sans-serif',
              fontSize: '1rem',
              color: '#555',
            }}
          >
            <FlightRecommendations flights={selectedFlights} preferredAirlines={preferredAirlies} userData={userData} />
          </DialogContent>
        </Dialog>
        
        <Dialog
          open={showHotelModal}
          onClose={() => setShowHotelModal(false)}
          maxWidth="lg"
          fullWidth
          sx={{
            '& .MuiDialog-paper': {
              borderRadius: '16px',
              padding: '16px',
              boxShadow: '0 4px 16px rgba(0, 0, 0, 0.1)',
            },
          }}
        >
          <DialogTitle
            sx={{
              fontSize: '1.6rem',
              fontWeight: 'bold',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              borderBottom: '1px solid #e0e0e0',
              paddingBottom: '8px',
              color: '#006E74', // Use the theme's primary color
              backgroundColor: 'background.paper', // Matches the page's background theme
            }}
          >
            Hotel Recommendations
            <IconButton
              onClick={() => setShowHotelModal(false)}
              sx={{
                color: '#333',
                '&:hover': {
                  color: '#006E74',
                },
              }}
            >
              <Close />
            </IconButton>
          </DialogTitle>
          <DialogContent
            sx={{
              paddingTop: '16px',
              paddingBottom: '16px',
              fontFamily: 'Roboto, sans-serif',
              fontSize: '1rem',
              color: '#555',
            }}
          >
            <HotelRecommendations hotels={selectedHotels} preferredHotels={preferredHotels} userData={userData} />
          </DialogContent>
        </Dialog>

        <Dialog
          open={showRestaurantModal}
          onClose={() => setShowRestaurantModal(false)}
          maxWidth="lg"
          fullWidth
          sx={{
            '& .MuiDialog-paper': {
              borderRadius: '16px',
              padding: '16px',
              boxShadow: '0 4px 16px rgba(0, 0, 0, 0.1)',
            },
          }}
        >
          <DialogTitle
            sx={{
              fontSize: '1.6rem',
              fontWeight: 'bold',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              borderBottom: '1px solid #e0e0e0',
              paddingBottom: '8px',
              color: '#006E74', // Use the theme's primary color
              backgroundColor: 'background.paper', // Matches the page's background theme
            }}
          >
            Restaurants
            <IconButton
              onClick={() => setShowRestaurantModal(false)}
              sx={{
                color: '#333',
                '&:hover': {
                  color: '#006E74',
                },
              }}
            >
              <Close />
            </IconButton>
          </DialogTitle>
          <DialogContent
            sx={{
              paddingTop: '16px',
              paddingBottom: '16px',
              fontFamily: 'Roboto, sans-serif',
              fontSize: '1rem',
              color: '#555',
            }}
          >
            <RestaurantsRecommendations restaurants={selectedRestaurants} preferredRestaurants={preferredRestaurants} userData={userData} />
          </DialogContent>
        </Dialog>

      </Box>
      <ToastContainer />
    </Container>
  );
};

export default RecommendationDashboard;