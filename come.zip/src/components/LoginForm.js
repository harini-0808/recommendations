import React, { useState } from "react";
import axios from "axios";
import {
  Container,
  TextField,
  Button,
  Typography,
  Box,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  CircularProgress,
} from "@mui/material";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const LoginForm = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    email_id: "",
    password: "",
    role: "", // Role will be either "customer" or "admin"
  });
  const [loading, setLoading] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // Call the backend login endpoint
      const response = await axios.post("http://localhost:8001/login", formData);

      // Save response data to localStorage
      localStorage.setItem("userData", JSON.stringify(response.data));

      // Trigger the onLogin callback with the response data
      onLogin(response.data);

      // Show a success toaster message
      toast.success("Login Successful!", {
        position: "top-right",
      });
    } catch (error) {
      // Handle login error
      console.error("Login failed:", error);
      const errorMessage =
        error.response?.data?.detail ||
        "Login Failed. Please check your credentials.";
      toast.error(errorMessage, {
        position: "top-right",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="xs">
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          height: "100vh",
          py: 4,
        }}
      >
        <Typography
          variant="h4"
          component="h1"
          gutterBottom
          sx={{
            fontWeight: 600, // Slightly lighter than bold for a modern feel
            fontSize: "2.25rem", // Larger font size for prominence
            letterSpacing: "0.5px", // Add letter spacing for a smoother look
            color: "#006E74", // Match with the theme's primary color
            textTransform: "uppercase", // Make it uppercase for emphasis
            textAlign: "center", // Center the text
            marginBottom: 4,
            fontFamily: "'Poppins', sans-serif", // Use a modern font
          }}
        >
          Login
        </Typography>

        <form onSubmit={handleSubmit} style={{ width: "100%" }}>
          <TextField
            label="Email ID"
            name="email_id"
            type="email"
            value={formData.email_id}
            onChange={handleInputChange}
            fullWidth
            required
            margin="normal"
            disabled={loading}
          />
          <TextField
            label="Password"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleInputChange}
            fullWidth
            required
            margin="normal"
            disabled={loading}
          />
          {/* Dropdown for Role */}
          <FormControl fullWidth margin="normal" required disabled={loading}>
            <InputLabel id="role-label">Role</InputLabel>
            <Select
              labelId="role-label"
              id="role"
              name="role"
              value={formData.role}
              onChange={handleInputChange}
              label="Role"
              sx={{
                "& .MuiSelect-select": {
                  textAlign: "left", // Ensure the selected value is aligned to the left
                },
              }}
            >
              <MenuItem value="customer">Customer</MenuItem>
              <MenuItem value="admin">Admin</MenuItem>
            </Select>
          </FormControl>
          <Button
            type="submit"
            variant="contained"
            sx={{
              width: "100%",
              backgroundColor: "#006E74",
              color: "white",
              marginTop: 2,
              "&:hover": {
                backgroundColor: "#004F52",
              },
            }}
            disabled={loading}
          >
            {loading ? <CircularProgress size={24} color="inherit" /> : "Login"}
          </Button>
        </form>
        <Box sx={{ display: "flex", justifyContent: "center", mt: 3 }}>
          <Typography variant="body2" color="text.secondary">
            Need help?{" "}
          </Typography>
          <Typography
            variant="body2"
            sx={{
              fontWeight: "bold",
              color: "#006E74",
              cursor: "pointer",
              ml: 1,
            }}
          >
            Contact Admin
          </Typography>
        </Box>
      </Box>
      <ToastContainer />
    </Container>
  );
};

export default LoginForm;