import React from 'react';
import { 
  Card, 
  CardContent, 
  Typography, 
  Grid, 
  Box, 
  Divider, 
  Avatar, 
  Chip,
  useTheme 
} from '@mui/material';
import { 
  FlightTakeoff, 
  FlightLand, 
  Hotel, 
  LocationOn, 
  AttachMoney, 
  AccessTime, 
  CalendarToday,
  AirplaneTicket,
  Bed,
  Airlines
} from '@mui/icons-material';
import FlightClassIcon from '@mui/icons-material/FlightClass';

const TravelPatternCards = ({ travelPattern }) => {
  const theme = useTheme();
  
  if (!travelPattern) return null;

  const iconStyle = {
    backgroundColor: '#006E74',
    color: 'white',
    width: 40,
    height: 40
  };

  const boxStyle = {
    bgcolor: '#f5fffe',
    borderRadius: 2,
    p: 2,
    border: '1px solid #e0f2f1',
    height: '100px',
    display: 'flex',
    flexDirection: 'column'
  };

  const statsChip = (label, value, icon) => (
    <Chip
      label={<><strong>{label}:</strong> {value}</>}
      variant="outlined"
      avatar={
        <Avatar sx={{ bgcolor: '#006E74' }}>
          {React.cloneElement(icon, { sx: { color: 'white' } })}
        </Avatar>
      }
      sx={{ 
        m: 0.5,
        borderColor: '#e0e0e0',
        '& .MuiChip-label': { 
          px: 1.5,
          py: 1,
          whiteSpace: 'normal',
          height: 'auto',
          maxWidth: '250px'
        },
        height: 'auto'
      }}
    />
  );

  return (
    <Box sx={{ px: { xs: 1, md: 4 }, py: 3 }}>
      <Typography 
        variant="h4" 
        sx={{ 
          mb: 4,
          color: '#006E74',
          fontWeight: 700,
          textAlign: 'center',
          fontSize: { xs: '1.75rem', md: '2.125rem' }
        }}
      >
        Your Travel Insights
      </Typography>
      
      <Grid container spacing={3}>
        {/* Flight Card */}
        <Grid item xs={12} md={6}>
          <Card 
            sx={{ 
              borderRadius: 3,
              boxShadow: '0 8px 32px rgba(0,110,116,0.1)',
              transition: 'transform 0.3s, box-shadow 0.3s',
              height: '100%',
              '&:hover': {
                transform: 'translateY(-4px)',
                boxShadow: '0 12px 40px rgba(0,110,116,0.2)'
              }
            }}
          >
            <CardContent>
              <Box display="flex" alignItems="center" mb={2}>
                <Avatar sx={iconStyle}>
                  <AirplaneTicket fontSize="medium" />
                </Avatar>
                <Typography variant="h6" sx={{ ml: 2, fontWeight: 700, color: '#006E74' }}>
                  Flight Preferences
                </Typography>
              </Box>
              
              <Divider sx={{ borderColor: '#e0e0e0', mb: 2 }} />
              
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, alignItems: 'flex-start' }}>
                    {statsChip('Departures', travelPattern.common_departures.join(', '), <FlightTakeoff />)}
                    {statsChip('Arrivals', travelPattern.common_arrivals.join(', '), <FlightLand />)}
                    {statsChip('Airlines', travelPattern.preferred_airlines.join(', '), <Airlines />)}
                    {statsChip('Classes', travelPattern.preferred_classes.join(', '), <FlightClassIcon />)}
                  </Box>
                </Grid>
                
                <Grid item xs={12} sx={{ mt: 2 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <Box sx={boxStyle}>
                        <Typography variant="subtitle2" sx={{ color: '#006E74', mb: 1 }}>
                          <AccessTime sx={{ verticalAlign: 'middle', mr: 1 }} />
                          Preferred Time
                        </Typography>
                        <Chip 
                          label={travelPattern.preferred_time_range} 
                          sx={{ bgcolor: '#e0f2f1', color: '#006E74' }}
                        />
                      </Box>
                    </Grid>
                    
                    <Grid item xs={6}>
                      <Box sx={boxStyle}>
                        <Typography variant="subtitle2" sx={{ color: '#006E74', mb: 1 }}>
                          <AttachMoney sx={{ verticalAlign: 'middle', mr: 1 }} />
                          Price Range
                        </Typography>
                        <Typography 
                          variant="h6" 
                          sx={{ 
                            fontFamily: 'Roboto Mono, monospace',
                            fontWeight: 600,
                            color: '#006E74'
                          }}
                        >
                          ₹{travelPattern.avg_flight_price_range.min} - ₹{travelPattern.avg_flight_price_range.max}
                        </Typography>
                      </Box>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        {/* Hotel Card */}
        <Grid item xs={12} md={6}>
          <Card 
            sx={{ 
              borderRadius: 3,
              boxShadow: '0 8px 32px rgba(0,110,116,0.1)',
              transition: 'transform 0.3s, box-shadow 0.3s',
              height: '100%',
              '&:hover': {
                transform: 'translateY(-4px)',
                boxShadow: '0 12px 40px rgba(0,110,116,0.2)'
              }
            }}
          >
            <CardContent>
              <Box display="flex" alignItems="center" mb={2}>
                <Avatar sx={iconStyle}>
                  <Bed fontSize="medium" />
                </Avatar>
                <Typography variant="h6" sx={{ ml: 2, fontWeight: 700, color: '#006E74' }}>
                  Hotel Preferences
                </Typography>
              </Box>
              
              <Divider sx={{ borderColor: '#e0e0e0', mb: 2 }} />
              
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Box sx={boxStyle}>
                    <Typography variant="subtitle2" sx={{ color: '#006E74', mb: 1 }}>
                      <CalendarToday sx={{ verticalAlign: 'middle', mr: 1 }} />
                      Average Stay
                    </Typography>
                    <Chip 
                      label={`${travelPattern.avg_hotel_days} days`} 
                      sx={{ 
                        bgcolor: '#e0f2f1', 
                        color: '#006E74',
                        fontSize: '1.1rem'
                      }}
                    />
                  </Box>
                </Grid>
                
                <Grid item xs={6}>
                  <Box sx={boxStyle}>
                    <Typography variant="subtitle2" sx={{ color: '#006E74', mb: 1 }}>
                      <AttachMoney sx={{ verticalAlign: 'middle', mr: 1 }} />
                      Price Range
                    </Typography>
                    <Typography 
                      variant="h6" 
                      sx={{ 
                        fontFamily: 'Roboto Mono, monospace',
                        fontWeight: 600,
                        color: '#006E74'
                      }}
                    >
                      ₹{travelPattern.avg_hotel_price_range.min} - ₹{travelPattern.avg_hotel_price_range.max}
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default TravelPatternCards;