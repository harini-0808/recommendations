import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Typography, Grid, Paper, Box } from '@mui/material';
import FlightIcon from '@mui/icons-material/Flight';
import HotelIcon from '@mui/icons-material/Hotel';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';

const AdminConfigPage = () => {
  const navigate = useNavigate();
  const [userName, setUserName] = useState('');

  useEffect(() => {
    // Get the user data from localStorage
    const userData = JSON.parse(localStorage.getItem('userData'));
    setUserName(userData?.customer_name || 'User');
  }, []); // Run only once on component mount

  return (
    <Container maxWidth="xl" sx={{ py: 4, position: 'relative' }}>
      <Box
        sx={{
          position: 'absolute',
          top: 20,
          right: 16,
          display: 'flex',
          alignItems: 'center',
          gap: 1,
          backgroundColor: '#f0f4f6',
          padding: '8px 16px',
          borderRadius: 2,
          boxShadow: 1,
          color: '#006E74',
        }}
      >
        <PersonOutlineIcon sx={{ fontSize: 24, mr: 1 }} />
        <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
          Hello, {userName}
        </Typography>
      </Box>

      <Container>
        <Typography
          variant="h4"
          sx={{
            fontWeight: 'bold',
            color: '#006E74',
            mb: 4,
            letterSpacing: '1px',
            textAlign: 'left',
            borderBottom: '2px solid #006E74',
            paddingBottom: 1,
            width: '100%',
          }}
        >
          Admin Configuration Page
        </Typography>

        <Box sx={{ mb: 4, backgroundColor: '#f0f4f6', p: 3, borderRadius: 2 }}>
          <Typography variant="body1" sx={{ color: '#333', lineHeight: 1.6 }}>
            Welcome to the Admin Configuration Dashboard. You can easily add and configure flight and hotel offers,
            helping to maintain an up-to-date and comprehensive travel recommendation system. Use the tiles below to
            access specific configuration options for flights and hotels.
          </Typography>
        </Box>

        <Grid container spacing={4}>
          {/* Tile for Adding Flights */}
          <Grid item xs={12} sm={6}>
            <Paper
              elevation={3}
              onClick={() => navigate('/add-flights')}
              sx={{
                cursor: 'pointer',
                padding: '30px',
                height: '100%',
                textAlign: 'center',
                backgroundColor: '#f0faff',
                border: '2px solid #006E74',
                borderRadius: '10px',
                transition: 'transform 0.2s, box-shadow 0.2s',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                '&:hover': {
                  transform: 'scale(1.05)',
                  boxShadow: '0 8px 16px rgba(0, 110, 116, 0.3)',
                },
              }}
            >
              <FlightIcon
                sx={{
                  fontSize: 60,
                  color: '#006E74',
                  mb: 2,
                  alignSelf: 'center',
                  backgroundColor: '#e0f7fa',
                  borderRadius: '50%',
                  padding: '10px',
                }}
              />
              <Typography
                variant="h5"
                gutterBottom
                sx={{ fontWeight: 'bold', color: '#006E74', mb: 2 }}
              >
                Add Flight Offers
              </Typography>
              <Box>
                <Typography variant="body1" sx={{ color: '#555', fontStyle: 'italic' }}>
                  Configure and manage flight offers easily.
                </Typography>
              </Box>
            </Paper>
          </Grid>

          {/* Tile for Adding Hotels */}
          <Grid item xs={12} sm={6}>
            <Paper
              elevation={3}
              onClick={() => navigate('/add-hotels')}
              sx={{
                cursor: 'pointer',
                padding: '30px',
                height: '100%',
                textAlign: 'center',
                backgroundColor: '#f0fff4',
                border: '2px solid #006E74',
                borderRadius: '10px',
                transition: 'transform 0.2s, box-shadow 0.2s',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                '&:hover': {
                  transform: 'scale(1.05)',
                  boxShadow: '0 8px 16px rgba(0, 110, 116, 0.3)',
                },
              }}
            >
              <HotelIcon
                sx={{
                  fontSize: 60,
                  color: '#006E74',
                  mb: 2,
                  alignSelf: 'center',
                  backgroundColor: '#e0f7fa',
                  borderRadius: '50%',
                  padding: '10px',
                }}
              />
              <Typography
                variant="h5"
                gutterBottom
                sx={{ fontWeight: 'bold', color: '#006E74', mb: 2 }}
              >
                Add Hotel Offers
              </Typography>
              <Box>
                <Typography variant="body1" sx={{ color: '#555', fontStyle: 'italic' }}>
                  Configure and manage hotel offers easily.
                </Typography>
              </Box>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </Container>
  );
};

export default AdminConfigPage;