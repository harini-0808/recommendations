import React, { useState } from "react";
import {
  Typography,
  TextField,
  Button,
  Grid,
  Box,
  Card,
  CardContent,
} from "@mui/material";
import Autocomplete from "@mui/material/Autocomplete";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import PercentIcon from "@mui/icons-material/Percent";
import FlightIcon from "@mui/icons-material/Flight";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import LocalOfferIcon from "@mui/icons-material/LocalOffer";
import CalculateIcon from "@mui/icons-material/Calculate";
import axios from "axios";

// Define airline list with IATA codes and names
const airlines = [
  { code: "6E", name: "IndiGo" },
  { code: "AA", name: "American Airlines" },
  { code: "AC", name: "Air Canada" },
  { code: "AF", name: "Air France" },
  { code: "AI", name: "Air India" },
  { code: "AY", name: "Finnair" },
  { code: "BA", name: "British Airways" },
  { code: "CX", name: "Cathay Pacific" },
  { code: "DL", name: "Delta Air Lines" },
  { code: "EK", name: "Emirates" },
  { code: "EY", name: "Etihad Airways" },
  { code: "HA", name: "Hawaiian Airlines" },
  { code: "IB", name: "Iberia" },
  { code: "KE", name: "Korean Air" },
  { code: "LA", name: "LATAM Airlines" },
  { code: "LH", name: "Lufthansa" },
  { code: "NH", name: "All Nippon Airways" },
  { code: "QF", name: "Qantas" },
  { code: "QR", name: "Qatar Airways" },
  { code: "SQ", name: "Singapore Airlines" },
  { code: "TG", name: "Thai Airways" },
  { code: "UA", name: "United Airlines" },
  { code: "UK", name: "Vistara" },
  { code: "VS", name: "Virgin Atlantic" },
  { code: "QP", name: "Akasa Air" },
];

const pageStyles = {
  minHeight: "100vh",
  backgroundColor: "#F0F8FF",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  padding: "2rem 0",
};

const cardStyles = {
  maxWidth: 600,
  borderRadius: "14px",
  boxShadow: "0px 10px 30px rgba(0, 0, 0, 0.1)",
};

const typographyStyles = {
  color: "#006E74",
  fontWeight: "700",
  textAlign: "center",
  marginBottom: "1.5rem",
  letterSpacing: "0.06rem",
};

const inputStyles = {
  "& .MuiOutlinedInput-root": {
    borderRadius: "14px",
    "&.Mui-focused fieldset": {
      borderColor: "#006E74",
    },
  },
  "& .MuiInputLabel-root": {
    color: "#006E74",
    fontSize: "1rem",
    fontWeight: "500",
  },
  "& .MuiInputLabel-root.Mui-focused": {
    color: "#006E74",
  },
};

const buttonStyles = {
  fontSize: 16,
  fontWeight: "bold",
  paddingY: 1.5,
  color: "#FFFFFF",
  backgroundColor: "#006E74",
  textTransform: "none",
  borderRadius: "14px",
  width: "100%",
  transition: "all 0.3s ease",
  boxShadow: "0px 5px 15px rgba(0, 110, 116, 0.3)",
  "&:hover": {
    backgroundColor: "#004F52",
    transform: "translateY(-3px)",
    boxShadow: "0 8px 20px rgba(16, 185, 129, 0.4)",
  },
};

const AddFlightPage = () => {
  const [flightOffer, setFlightOffer] = useState({
    offer_percentage: "",
    offer_name: "",
    offer_airline: "",
    offer_start_date: "",
    offer_end_date: "",
    airline_point: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFlightOffer((prev) => ({ ...prev, [name]: value }));
  };

  // Modified to validate that an airline has been selected
  const validateInput = () => {
    const { offer_percentage, offer_airline, offer_start_date, offer_end_date, airline_point } = flightOffer;

    if (offer_percentage < 1 || offer_percentage > 100) {
      toast.error("Offer Percentage must be between 1 and 100", {
        position: "top-right",
      });
      return false;
    }

    // Ensure an airline code has been set (should be exactly 2 characters)
    if (offer_airline.length !== 2) {
      toast.error("Please select a valid airline", {
        position: "top-right",
      });
      return false;
    }

    if (new Date(offer_start_date) >= new Date(offer_end_date)) {
      toast.error("Start date must be earlier than End date", {
        position: "top-right",
      });
      return false;
    }

    if (
      airline_point === "" ||
      isNaN(airline_point) ||
      parseFloat(airline_point) <= 0 ||
      parseFloat(airline_point) >= 1
    ) {
      toast.error("Airline point must be a valid number between 0 and 1", {
        position: "top-right",
      });
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateInput()) return;

    try {
      await axios.post("http://localhost:8001/flight-offers", flightOffer);

      toast.success("Flight offer added successfully!", {
        position: "top-right",
      });

      setFlightOffer({
        offer_percentage: "",
        offer_name: "",
        offer_airline: "",
        offer_start_date: "",
        offer_end_date: "",
        airline_point: "",
      });
    } catch (error) {
      toast.error(
        error.response?.data?.detail || "Error adding flight offer.",
        {
          position: "top-right",
        }
      );
    }
  };

  return (
    <Box sx={pageStyles}>
      <Card sx={cardStyles}>
        <CardContent>
          <Typography variant="h4" gutterBottom sx={typographyStyles}>
            Add Flight Offer
          </Typography>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Offer Name"
                  name="offer_name"
                  value={flightOffer.offer_name}
                  onChange={handleChange}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: <LocalOfferIcon sx={{ color: "#006E74", mr: 1 }} />,
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Offer Percentage"
                  name="offer_percentage"
                  type="number"
                  value={flightOffer.offer_percentage}
                  onChange={handleChange}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: <PercentIcon sx={{ color: "#006E74", mr: 1 }} />,
                  }}
                />
              </Grid>
              {/* Replaced Airline TextField with Autocomplete */}
              <Grid item xs={12}>
                <Autocomplete
                  options={airlines}
                  getOptionLabel={(option) => `${option.name} (${option.code})`}
                  value={
                    airlines.find((a) => a.code === flightOffer.offer_airline) || null
                  }
                  onChange={(_, newValue) =>
                    setFlightOffer((prev) => ({
                      ...prev,
                      offer_airline: newValue ? newValue.code : "",
                    }))
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Airline"
                      required
                      variant="outlined"
                      sx={inputStyles}
                      InputProps={{
                        ...params.InputProps,
                        startAdornment: (
                          <>
                            <FlightIcon sx={{ color: "#006E74", mr: 1 }} />
                            {params.InputProps.startAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Start Date"
                  type="date"
                  name="offer_start_date"
                  value={flightOffer.offer_start_date}
                  onChange={handleChange}
                  InputLabelProps={{ shrink: true }}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: <CalendarMonthIcon sx={{ color: "#006E74", mr: 1 }} />,
                  }}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="End Date"
                  type="date"
                  name="offer_end_date"
                  value={flightOffer.offer_end_date}
                  onChange={handleChange}
                  InputLabelProps={{ shrink: true }}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: <CalendarMonthIcon sx={{ color: "#006E74", mr: 1 }} />,
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Airline Point"
                  name="airline_point"
                  type="number"
                  step="0.01"
                  value={flightOffer.airline_point}
                  onChange={handleChange}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: <CalculateIcon sx={{ color: "#006E74", mr: 1 }} />,
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <Button variant="contained" type="submit" sx={buttonStyles}>
                  Submit Flight Offer
                </Button>
              </Grid>
            </Grid>
          </form>
        </CardContent>
      </Card>
      <ToastContainer />
    </Box>
  );
};

export default AddFlightPage;