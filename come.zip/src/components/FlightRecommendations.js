import React from 'react';
import {
  Box,
  Paper,
  Typography,
  Chip,
  Divider,
  Grid
} from '@mui/material';
import FlightTakeoffIcon from '@mui/icons-material/FlightTakeoff';
import FlightLandIcon from '@mui/icons-material/FlightLand';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';
import TimerIcon from '@mui/icons-material/Timer';
import ConnectingAirportsIcon from '@mui/icons-material/ConnectingAirports';

const FlightCard = ({ flight, userData }) => {
  // Calculate discounted price using userData.travel_points and the airline's point value.
  let discountedPrice = null;
  if (userData && flight.offers && flight.offers.f_point_value != null) {
    discountedPrice = Math.round(userData.travel_points * flight.offers.f_point_value);
  }

  const renderSegments = () => {
    return flight.segments.map((segment, index) => (
      <Box 
        key={index} 
        sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: 2, 
          mb: 1,
          p: 1,
          backgroundColor: index % 2 === 0 ? '#f0f4f6' : 'white'
        }}
      >
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          {index === 0 ? (
            <FlightTakeoffIcon sx={{ color: '#006E74' }} />
          ) : (
            <ConnectingAirportsIcon color="secondary" />
          )}
        </Box>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={4}>
            <Typography variant="body2" fontWeight="bold">
              {segment.departure_airport.name} ({segment.departure_airport.code})
            </Typography>
            <Typography variant="caption">
              {new Date(segment.departure_airport.time).toLocaleString()}
            </Typography>
          </Grid>
          <Grid item xs={4}>
            <Typography variant="body2" fontWeight="bold">
              {segment.arrival_airport.name} ({segment.arrival_airport.code})
            </Typography>
            <Typography variant="caption">
              {new Date(segment.arrival_airport.time).toLocaleString()}
            </Typography>
          </Grid>
          <Grid item xs={4}>
            <Chip 
              icon={<TimerIcon />}
              label={`${segment.duration} mins`}
              variant="outlined"
              size="small"
            />
          </Grid>
        </Grid>
      </Box>
    ));
  };

  return (
    <Paper 
      elevation={3} 
      sx={{ 
        mb: 2, 
        p: 2, 
        borderRadius: 2,
        border: '1px solid #e0e0e0'
      }}
    >
      <Box 
        sx={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center', 
          mb: 2 
        }}
      >
        <Typography variant="h6" sx={{ color: '#006E74' }}>
          {flight.segments[0].airline}
        </Typography>

        {flight.offers && flight.offers.f_offers && flight.offers.f_offers.length > 0 && (
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
            {flight.offers.f_offers.map((offer, index) => (
              <Chip
                key={index}
                icon={<LocalOfferIcon style={{ fontSize: 16 }} />}
                label={
                  <Typography variant="caption" sx={{ fontSize: "0.8rem" }}>
                    {`${offer.offer_name} (${offer.offer_percentage}% OFF)`}
                  </Typography>
                }
                color="secondary"
                variant="outlined"
                size="small"
              />
            ))}
          </Box>
        )}
      </Box>

      {renderSegments()}

      <Divider sx={{ my: 2 }} />

      <Grid container spacing={2}>
        <Grid item xs={4}>
          <Typography variant="body2">
            <strong>Total Duration:</strong> {flight.total_duration} mins
          </Typography>
        </Grid>
        <Grid item xs={4}>
          <Chip 
            label={flight.is_direct ? 'Direct Flight' : `${flight.num_stops} Stops`}
            color={flight.is_direct ? 'success' : 'warning'}
            size="small"
          />
        </Grid>
        <Grid item xs={4}>
          <Box sx={{ textAlign: "right" }}>
            <Typography variant="h6" sx={{ color: '#006E74' }}>
              {flight.price?.formatted || 'Price N/A'}
            </Typography>
            {discountedPrice !== null && discountedPrice!==0 && (
              <Chip
                label={`Travel Points Discount: ₹${discountedPrice}`}
                color="primary"
                size="small"
                sx={{ mt: 1 }}
              />
            )}
          </Box>
        </Grid>
      </Grid>
    </Paper>
  );
};

const FlightRecommendations = ({ flights = [], preferredAirlines = [], userData }) => {
  
  const getAirlineCode = (flight) => {
    return flight.segments[0].flight_number.split(' ')[0];
  };

  const preferredFlights = [];
  const otherFlights = [];

  if (preferredAirlines.length > 0) {
    flights.forEach(flight => {
      const airlineCode = getAirlineCode(flight);
      preferredAirlines.includes(airlineCode) ? 
        preferredFlights.push(flight) : 
        otherFlights.push(flight);
    });
  }

  return (
    <Box sx={{ p: 2 }}>
      {flights.length === 0 ? (
        <Typography variant="body1">
          No flight recommendations available.
        </Typography>
      ) : (
        <>
          {preferredAirlines.length > 0 && (
            <>
              {preferredFlights.length > 0 && (
                <Box sx={{ mb: 4 }}>
                  <Typography variant="h5" sx={{ mb: 2, color: '#006E74', fontWeight: 'bold' }}>
                    Preferred Airlines
                  </Typography>
                  {preferredFlights.map((flight, index) => (
                    <FlightCard key={`preferred-${index}`} flight={flight} userData={userData} />
                  ))}
                </Box>
              )}
              
              {otherFlights.length > 0 && (
                <Box>
                  <Typography variant="h5" sx={{ mb: 2, color: '#006E74', fontWeight: 'bold' }}>
                    Other Airlines
                  </Typography>
                  {otherFlights.map((flight, index) => (
                    <FlightCard key={`other-${index}`} flight={flight} userData={userData} />
                  ))}
                </Box>
              )}
            </>
          )}
          
          {preferredAirlines.length === 0 && (
            flights.map((flight, index) => (
              <FlightCard key={index} flight={flight} userData={userData} />
            ))
          )}
        </>
      )}
    </Box>
  );
};

export default FlightRecommendations;