import React from "react";
import {
  Box,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Chip,
  Button,
  Grid,
} from "@mui/material";
import {
  Restaurant as LocalDiningIcon,
  Phone as PhoneIcon,
  Schedule as ScheduleIcon,
  LocationOn as LocationOnIcon,
  Star as StarIcon,
} from "@mui/icons-material";

const RestaurantsRecommendations = ({
  restaurants = [],
  preferredRestaurants = [],
  userData,
}) => {
  const defaultImage =
    "https://via.placeholder.com/300x200?text=No+Image+Available";

  // Updated helper function to format hours without extra hyphens
  const getFormattedHours = (hours) => {
    if (!hours) return "";
    const opening = hours.opening?.trim() || "";
    const closing = hours.closing?.trim() || "";
    if (!opening && !closing) return "";
    // If either part already contains a dash, assume it's preformatted
    if (opening.includes("-") || closing.includes("-")) {
      return `${opening} ${closing}`.trim();
    }
    return opening && closing ? `${opening} - ${closing}` : opening || closing;
  };

  // Helper function to render a restaurant card
  const renderRestaurantCard = (restaurant, index) => {
    return (
      <Grid item xs={12} key={index}>
        <Card
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            borderRadius: 2,
            border: "1px solid #e0e0e0",
            boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.05)",
            minHeight: { xs: "auto", md: 250 },
            overflow: "hidden",
          }}
        >
          <CardMedia
            component="img"
            sx={{
              width: { xs: "100%", md: 200 },
              height: { xs: 200, md: 250 },
              objectFit: "cover",
              objectPosition: "center",
              borderRight: { md: "1px solid #e0e0e0" },
              p: 1,
              borderRadius: 1,
            }}
            image={restaurant.images?.thumbnail || restaurant.images?.photos_link || defaultImage}
            alt={restaurant.name}
          />

          <Box sx={{ display: "flex", flexDirection: "column", flex: 1 }}>
            <CardContent sx={{ flex: "1 0 auto", p: 2 }}>
              <Box sx={{ mb: 1.5 }}>
                <Typography
                  variant="h6"
                  sx={{ color: "#006E74", fontWeight: 600, mb: 0.5 }}
                >
                  {restaurant.name}
                  {restaurant.rating && (
                    <Box
                      component="span"
                      sx={{
                        ml: 1,
                        display: "inline-flex",
                        alignItems: "center",
                        fontSize: "0.85rem",
                        color: "#666",
                      }}
                    >
                      <StarIcon sx={{ color: "#FFB400", fontSize: "1rem" }} />
                      {restaurant.rating}/5{" "}
                      {restaurant.reviews &&
                        `(${restaurant.reviews.toLocaleString()})`}
                    </Box>
                  )}
                </Typography>
              </Box>

              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Box sx={{ display: "flex", flexDirection: "column", gap: 1 }}>
                    {restaurant.type && (
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <LocalDiningIcon
                          sx={{ fontSize: "1.2rem", color: "action.active" }}
                        />
                        <Typography variant="body2" color="text.secondary">
                          {restaurant.type}
                        </Typography>
                      </Box>
                    )}

                    {restaurant.address && (
                      <Box
                        sx={{
                          display: "flex",
                          alignItems: "flex-start",
                          gap: 1,
                        }}
                      >
                        <LocationOnIcon
                          sx={{
                            fontSize: "1.2rem",
                            color: "action.active",
                            mt: 0.2,
                          }}
                        />
                        <Typography
                          variant="body2"
                          color="text.secondary"
                          sx={{ flex: 1 }}
                        >
                          {restaurant.address}
                        </Typography>
                      </Box>
                    )}
                  </Box>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Box sx={{ display: "flex", flexDirection: "column", gap: 1 }}>
                    {restaurant.phone && (
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <PhoneIcon
                          sx={{ fontSize: "1.2rem", color: "action.active" }}
                        />
                        <Typography
                          component="a"
                          href={`tel:${restaurant.phone}`}
                          variant="body2"
                          sx={{
                            color: "text.secondary",
                            textDecoration: "none",
                            "&:hover": { color: "#006E74" },
                          }}
                        >
                          {restaurant.phone}
                        </Typography>
                      </Box>
                    )}

                    {restaurant.hours && (
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <ScheduleIcon
                          sx={{ fontSize: "1.2rem", color: "action.active" }}
                        />
                        <Typography variant="body2" color="text.secondary">
                          {getFormattedHours(restaurant.hours)}
                        </Typography>
                      </Box>
                    )}
                  </Box>
                </Grid>
              </Grid>

              {restaurant.service_options &&
                Object.values(restaurant.service_options).some(Boolean) && (
                  <Box sx={{ mt: 2 }}>
                    <Box sx={{ display: "flex", gap: 0.5, flexWrap: "wrap" }}>
                      {restaurant.service_options.delivery && (
                        <Chip
                          label="Delivery"
                          size="small"
                          sx={{
                            bgcolor: "#E3F2FD",
                            color: "#0277BD",
                            fontSize: "0.75rem",
                          }}
                        />
                      )}
                      {restaurant.service_options.takeout && (
                        <Chip
                          label="Takeout"
                          size="small"
                          sx={{
                            bgcolor: "#E8F5E9",
                            color: "#2E7D32",
                            fontSize: "0.75rem",
                          }}
                        />
                      )}
                      {restaurant.service_options.dine_in && (
                        <Chip
                          label="Dine-in"
                          size="small"
                          sx={{
                            bgcolor: "#FFF3E0",
                            color: "#E65100",
                            fontSize: "0.75rem",
                          }}
                        />
                      )}
                    </Box>
                  </Box>
                )}

              {restaurant.coordinates && (
                <Button
                  variant="outlined"
                  size="small"
                  sx={{
                    mt: 2,
                    borderColor: "#006E74",
                    color: "#006E74",
                    textTransform: "none",
                    "&:hover": {
                      borderColor: "#005054",
                      bgcolor: "rgba(0, 110, 116, 0.04)",
                    },
                  }}
                  href={`https://www.google.com/maps/search/?api=1&query=${restaurant.coordinates.latitude},${restaurant.coordinates.longitude}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  View on Map
                </Button>
              )}
            </CardContent>
          </Box>
        </Card>
      </Grid>
    );
  };

  if (restaurants.length === 0) {
    return (
      <Box sx={{ p: 2 }}>
        <Typography variant="body1" color="text.secondary">
          No restaurant recommendations available.
        </Typography>
      </Box>
    );
  }

  let content = null;
  if (preferredRestaurants.length > 0) {
    const preferredRestaurantNames = preferredRestaurants.map((name) =>
      name.toLowerCase().trim()
    );
    const preferredFiltered = restaurants.filter((restaurant) =>
      preferredRestaurantNames.includes(restaurant.name.toLowerCase())
    );
    const otherRestaurants = restaurants.filter(
      (restaurant) =>
        !preferredRestaurantNames.includes(restaurant.name.toLowerCase())
    );

    content = (
      <>
        {preferredFiltered.length > 0 && (
          <Box sx={{ mb: 4 }}>
            <Typography
              variant="h5"
              sx={{ mb: 2, color: "#006E74", fontWeight: "bold" }}
            >
              Preferred Restaurants
            </Typography>
            <Grid container spacing={2}>
              {preferredFiltered.map((restaurant, index) =>
                renderRestaurantCard(restaurant, index)
              )}
            </Grid>
          </Box>
        )}

        {otherRestaurants.length > 0 && (
          <Box>
            <Typography
              variant="h5"
              sx={{ mb: 2, color: "#006E74", fontWeight: "bold" }}
            >
              Other Restaurants
            </Typography>
            <Grid container spacing={2}>
              {otherRestaurants.map((restaurant, index) =>
                renderRestaurantCard(restaurant, index)
              )}
            </Grid>
          </Box>
        )}
      </>
    );
  } else {
    content = (
      <Grid container spacing={2}>
        {restaurants.map((restaurant, index) =>
          renderRestaurantCard(restaurant, index)
        )}
      </Grid>
    );
  }

  return <Box sx={{ p: 1 }}>{content}</Box>;
};

export default RestaurantsRecommendations;