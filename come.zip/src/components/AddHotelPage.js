import React, { useState } from "react";
import {
  Typography,
  TextField,
  Button,
  Grid,
  Box,
  Card,
  CardContent,
} from "@mui/material";
import Autocomplete from "@mui/material/Autocomplete";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import PercentIcon from "@mui/icons-material/Percent";
import LocationCityIcon from "@mui/icons-material/LocationCity";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import LocalOfferIcon from "@mui/icons-material/LocalOffer";
import AttachMoneyIcon from "@mui/icons-material/AttachMoney";
import CalculateIcon from "@mui/icons-material/Calculate";
import axios from "axios";

// Define your cities with their IATA codes and actual names
const cities = [
  { code: "AKL", name: "Auckland" },
  { code: "ATL", name: "Atlanta" },
  { code: "AUH", name: "Abu Dhabi" },
  { code: "BCN", name: "Barcelona" },
  { code: "BLR", name: "Bangalore" },
  { code: "BKK", name: "Bangkok" },
  { code: "BOM", name: "Mumbai" },
  { code: "BOS", name: "Boston" },
  { code: "CAI", name: "Cairo" },
  { code: "CDG", name: "Paris (Charles de Gaulle)" },
  { code: "CPH", name: "Copenhagen" },
  { code: "CCU", name: "Kolkata" },
  { code: "DEL", name: "Delhi" },
  { code: "DEN", name: "Denver" },
  { code: "DFW", name: "Dallas-Fort Worth" },
  { code: "DOH", name: "Doha" },
  { code: "DXB", name: "Dubai" },
  { code: "FCO", name: "Rome (Fiumicino)" },
  { code: "FRA", name: "Frankfurt" },
  { code: "GOI", name: "Goa" },
  { code: "GRU", name: "São Paulo" },
  { code: "HEL", name: "Helsinki" },
  { code: "HKG", name: "Hong Kong" },
  { code: "HND", name: "Tokyo (Haneda)" },
  { code: "HNL", name: "Honolulu" },
  { code: "HYD", name: "Hyderabad" },
  { code: "ICN", name: "Seoul (Incheon)" },
  { code: "JFK", name: "New York (JFK)" },
  { code: "KIX", name: "Osaka (Kansai)" },
  { code: "LAS", name: "Las Vegas" },
  { code: "LAX", name: "Los Angeles" },
  { code: "LHR", name: "London (Heathrow)" },
  { code: "LIS", name: "Lisbon" },
  { code: "MAD", name: "Madrid" },
  { code: "MIA", name: "Miami" },
  { code: "MEL", name: "Melbourne" },
  { code: "MUC", name: "Munich" },
  { code: "NRT", name: "Tokyo (Narita)" },
  { code: "ORD", name: "Chicago (O'Hare)" },
  { code: "PER", name: "Perth" },
  { code: "SCL", name: "Santiago" },
  { code: "SEA", name: "Seattle" },
  { code: "SIN", name: "Singapore" },
  { code: "SFO", name: "San Francisco" },
  { code: "SYD", name: "Sydney" },
  { code: "TPE", name: "Taipei" },
  { code: "TVM", name: "Thiruvananthapuram" },
  { code: "YVR", name: "Vancouver" },
  { code: "YYZ", name: "Toronto" },
];

const pageStyles = {
  minHeight: "100vh",
  backgroundColor: "#F0F8FF",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  padding: "2rem 0",
};

const cardStyles = {
  maxWidth: 600,
  borderRadius: "14px",
  boxShadow: "0px 10px 30px rgba(0, 0, 0, 0.1)",
};

const typographyStyles = {
  color: "#006E74",
  fontWeight: "700",
  textAlign: "center",
  marginBottom: "1.5rem",
  letterSpacing: "0.06rem",
};

const inputStyles = {
  "& .MuiOutlinedInput-root": {
    borderRadius: "14px",
    "&.Mui-focused fieldset": {
      borderColor: "#006E74",
    },
  },
  "& .MuiInputLabel-root": {
    color: "#006E74",
    fontSize: "1rem",
    fontWeight: "500",
  },
  "& .MuiInputLabel-root.Mui-focused": {
    color: "#006E74",
  },
};

const buttonStyles = {
  fontSize: 16,
  fontWeight: "bold",
  paddingY: 1.5,
  color: "#FFFFFF",
  backgroundColor: "#006E74",
  textTransform: "none",
  borderRadius: "14px",
  width: "100%",
  transition: "all 0.3s ease",
  boxShadow: "0px 5px 15px rgba(0, 110, 116, 0.3)",
  "&:hover": {
    backgroundColor: "#004F52",
    transform: "translateY(-3px)",
    boxShadow: "0 8px 20px rgba(16, 185, 129, 0.4)",
  },
};

const AddHotelPage = () => {
  const [hotelOffer, setHotelOffer] = useState({
    offer_percentage: "",
    offer_name: "",
    offer_arrival_id: "",
    offer_start_date: "",
    offer_end_date: "",
    min_price: "",
    max_price: "",
    point_value: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setHotelOffer((prev) => ({ ...prev, [name]: value }));
  };

  const validateInput = () => {
    const {
      offer_percentage,
      offer_arrival_id,
      offer_start_date,
      offer_end_date,
      min_price,
      max_price,
      point_value,
    } = hotelOffer;

    if (offer_percentage < 1 || offer_percentage > 100) {
      toast.error("Offer Percentage must be between 1% and 100%", {
        position: "top-right",
      });
      return false;
    }

    // Check that a valid city (i.e. 3-letter code) is selected
    if (!/^[A-Za-z]{3}$/.test(offer_arrival_id)) {
      toast.error("Please select a valid city", {
        position: "top-right",
      });
      return false;
    }

    if (new Date(offer_start_date) >= new Date(offer_end_date)) {
      toast.error("Start date must be earlier than End date", {
        position: "top-right",
      });
      return false;
    }

    if (min_price === "" || isNaN(min_price) || parseFloat(min_price) < 0) {
      toast.error("Minimum price must be a valid non-negative number", {
        position: "top-right",
      });
      return false;
    }

    if (max_price === "" || isNaN(max_price) || parseFloat(max_price) < 0) {
      toast.error("Maximum price must be a valid non-negative number", {
        position: "top-right",
      });
      return false;
    }

    if (parseFloat(max_price) < parseFloat(min_price)) {
      toast.error("Maximum price must be greater than or equal to Minimum price", {
        position: "top-right",
      });
      return false;
    }

    if (
      point_value === "" ||
      isNaN(point_value) ||
      parseFloat(point_value) <= 0 ||
      parseFloat(point_value) >= 1
    ) {
      toast.error("Point value must be a valid number between 0 and 1", {
        position: "top-right",
      });
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateInput()) return;

    try {
      await axios.post("http://localhost:8001/hotel-offers", hotelOffer);

      toast.success("Hotel offer added successfully!", {
        position: "top-right",
      });

      setHotelOffer({
        offer_percentage: "",
        offer_name: "",
        offer_arrival_id: "",
        offer_start_date: "",
        offer_end_date: "",
        min_price: "",
        max_price: "",
        point_value: "",
      });
    } catch (error) {
      toast.error(
        error.response?.data?.detail || "Error adding hotel offer.",
        {
          position: "top-right",
        }
      );
    }
  };

  return (
    <Box sx={pageStyles}>
      <Card sx={cardStyles}>
        <CardContent>
          <Typography variant="h4" gutterBottom sx={typographyStyles}>
            Add Hotel Offer
          </Typography>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Offer Name"
                  name="offer_name"
                  value={hotelOffer.offer_name}
                  onChange={handleChange}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: (
                      <LocalOfferIcon sx={{ color: "#006E74", mr: 1 }} />
                    ),
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Offer Percentage"
                  name="offer_percentage"
                  type="number"
                  value={hotelOffer.offer_percentage}
                  onChange={handleChange}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: (
                      <PercentIcon sx={{ color: "#006E74", mr: 1 }} />
                    ),
                  }}
                />
              </Grid>
              {/* Replace Arrival ID field with Autocomplete for Cities */}
              <Grid item xs={12}>
                <Autocomplete
                  options={cities}
                  getOptionLabel={(option) =>
                    `${option.name} (${option.code})`
                  }
                  value={
                    cities.find((c) => c.code === hotelOffer.offer_arrival_id) ||
                    null
                  }
                  onChange={(_, newValue) =>
                    setHotelOffer((prev) => ({
                      ...prev,
                      offer_arrival_id: newValue ? newValue.code : "",
                    }))
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="City"
                      required
                      variant="outlined"
                      sx={inputStyles}
                      InputProps={{
                        ...params.InputProps,
                        startAdornment: (
                          <>
                            <LocationCityIcon
                              sx={{ color: "#006E74", mr: 1 }}
                            />
                            {params.InputProps.startAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Start Date"
                  type="date"
                  name="offer_start_date"
                  value={hotelOffer.offer_start_date}
                  onChange={handleChange}
                  InputLabelProps={{ shrink: true }}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: (
                      <CalendarMonthIcon sx={{ color: "#006E74", mr: 1 }} />
                    ),
                  }}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="End Date"
                  type="date"
                  name="offer_end_date"
                  value={hotelOffer.offer_end_date}
                  onChange={handleChange}
                  InputLabelProps={{ shrink: true }}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: (
                      <CalendarMonthIcon sx={{ color: "#006E74", mr: 1 }} />
                    ),
                  }}
                />
              </Grid>
              <Grid item xs={4}>
                <TextField
                  fullWidth
                  label="Min Price (₹)"
                  name="min_price"
                  type="number"
                  value={hotelOffer.min_price}
                  onChange={handleChange}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: (
                      <AttachMoneyIcon sx={{ color: "#006E74", mr: 1 }} />
                    ),
                  }}
                />
              </Grid>
              <Grid item xs={4}>
                <TextField
                  fullWidth
                  label="Max Price (₹)"
                  name="max_price"
                  type="number"
                  value={hotelOffer.max_price}
                  onChange={handleChange}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: (
                      <AttachMoneyIcon sx={{ color: "#006E74", mr: 1 }} />
                    ),
                  }}
                />
              </Grid>
              <Grid item xs={4}>
                <TextField
                  fullWidth
                  label="Point Value"
                  name="point_value"
                  type="number"
                  step="0.01"
                  value={hotelOffer.point_value}
                  onChange={handleChange}
                  required
                  variant="outlined"
                  sx={inputStyles}
                  InputProps={{
                    startAdornment: (
                      <CalculateIcon sx={{ color: "#006E74", mr: 1 }} />
                    ),
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <Button variant="contained" type="submit" sx={buttonStyles}>
                  Submit Hotel Offer
                </Button>
              </Grid>
            </Grid>
          </form>
        </CardContent>
      </Card>
      <ToastContainer />
    </Box>
  );
};

export default AddHotelPage;