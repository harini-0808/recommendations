import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import AdminConfigPage from './components/AdminConfigPage';
import AddFlightPage from './components/AddFlightPage';
import AddHotelPage from './components/AddHotelPage';
import RecommendationDashboard from './components/RecommendationDashboard';

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState(null);

  const handleLogin = (userData) => {
    // Assuming userData contains a 'role' field
    localStorage.setItem('userData', JSON.stringify(userData));
    setIsLoggedIn(true);
    setUserRole(userData.role); // Set the user role based on the login response
  };

  const handleLogout = () => {
    localStorage.removeItem('userData');
    setIsLoggedIn(false);
    setUserRole(null);
  };

  return (
    <Router>
      <Routes>
        {/* Route for Login Form */}
        <Route
          path="/"
          element={
            !isLoggedIn ? (
              <LoginForm onLogin={handleLogin} />
            ) : (
              <Navigate to={userRole === 'admin' ? '/admin-config' : '/recommendations'} />
            )
          }
        />

        {/* Route for Recommendations Dashboard */}
        <Route
          path="/recommendations"
          element={
            isLoggedIn && userRole === 'customer' ? (
              <RecommendationDashboard onLogout={handleLogout} />
            ) : (
              <Navigate to="/" />
            )
          }
        />

        {/* Route for Admin Config Page */}
        <Route
          path="/admin-config"
          element={
            isLoggedIn && userRole === 'admin' ? (
              <AdminConfigPage onLogout={handleLogout} />
            ) : (
              <Navigate to="/" />
            )
          }
        />

        {/* Route for Add Flight Page */}
        <Route
          path="/add-flights"
          element={
            isLoggedIn && userRole === 'admin' ? (
              <AddFlightPage />
            ) : (
              <Navigate to="/" />
            )
          }
        />

        {/* Route for Add Hotel Page */}
        <Route
          path="/add-hotels"
          element={
            isLoggedIn && userRole === 'admin' ? (
              <AddHotelPage />
            ) : (
              <Navigate to="/" />
            )
          }
        />
      </Routes>
    </Router>
  );
};

export default App;